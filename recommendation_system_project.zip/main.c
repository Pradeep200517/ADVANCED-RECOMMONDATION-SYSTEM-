
#include <stdio.h>
#include "user.h"
#include "recommendations.c"

int main() {
    initUserTable();

    // Adding items for testing
    addItemToUser(1, 101, "Book A");
    addItemToUser(1, 102, "Book B");

    // Generating recommendations
    collaborativeFilterRecommendations(1);
    contentFilterRecommendations(1);

    return 0;
}
