
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "user.h"

User *userTable[MAX_USERS] = {NULL};

// Hash function for user ID
int hash(int user_id) {
    return user_id % MAX_USERS;
}

// Initialize the user table
void initUserTable() {
    for (int i = 0; i < MAX_USERS; i++) {
        userTable[i] = NULL;
    }
}

// Function to add item to user history
void addItemToUser(int user_id, int item_id, char *item_name) {
    int hashIndex = hash(user_id);
    User *user = userTable[hashIndex];

    // Check if user exists
    if (!user) {
        user = (User*)malloc(sizeof(User));
        user->user_id = user_id;
        user->items = NULL;
        userTable[hashIndex] = user;
    }

    // Add item to user's item list
    Item *newItem = (Item*)malloc(sizeof(Item));
    newItem->item_id = item_id;
    strcpy(newItem->name, item_name);
    newItem->next = user->items;
    user->items = newItem;
}

// Function to retrieve a user by ID
User* getUser(int user_id) {
    int hashIndex = hash(user_id);
    return userTable[hashIndex];
}
