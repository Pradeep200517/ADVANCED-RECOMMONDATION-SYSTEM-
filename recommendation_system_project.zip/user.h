
#ifndef USER_H
#define USER_H

#define MAX_USERS 100

typedef struct Item {
    int item_id;
    char name[50];
    struct Item *next; // Linked list for user history
} Item;

typedef struct User {
    int user_id;
    Item *items; // Linked list of items
} User;

// Hash table for users
extern User *userTable[MAX_USERS];

// Function declarations
void initUserTable();
void addItemToUser(int user_id, int item_id, char *item_name);
User* getUser(int user_id);

#endif
